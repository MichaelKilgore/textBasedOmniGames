
g++ server.cpp Networking.cpp Game.cpp Host.cpp -o server.o
g++ client.cpp Networking.cpp Game.cpp Player.cpp -o client.o
